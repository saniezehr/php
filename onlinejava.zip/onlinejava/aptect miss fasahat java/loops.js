// for (let i=1 ; i<=10 ; i++)
//     {
//         if(i==4 || i ==9){

//         }
//         else{
//             document.write(i +"<br>")
//         }
//     }

// let i =1
// do 
//     if(i==2){

//     }
//     else {
//         document.write(i+)
//         i++;                                        )
//     }
    

// let student= [
//     ["iqra",23,"malir"],
//     ["sani",16,"sharah e faisal"],
//     ["ali",25,"numaish"],
//     ["abiha",23,"landhi"],
//     ["ahmed",23,"saddar"]

// ]
// // document.write(student[1][2]) 
// for (let value of student ){
//     for (let value1 of value){
//         document.write(value1 +"<br>")
//     }
// }
// for (let data of student){
//     document.write(data[2]+"<br>")
// }


// let i = 1 ;
// do {if (i==2){
    
// }
// else{
//     document.write (i)
// }i++;
// }while (i<=5)
for (let rows = 1; rows <=10 ;rows++)
{
    document.write(rows)
}