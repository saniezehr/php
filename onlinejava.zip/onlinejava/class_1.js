let a = "appke";
let b ="banana";
{
let b = 30
console.log (b)
}
console.log(b);
