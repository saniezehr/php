let a= "sani"
let b = 43
document.write (a+b)
document.write (typeof (a+b))

const add = {
    name :"sani",
    age :16
}
add['city']="karachi"
console.log (add)
 const dict ={
    beautiful :"pleasing the senses or mind aesthetically",
    grateful :"feeling or showing an appreciation for something done or received",
    heathen :"a person who does not belong to a widely held religion (especially one who is not a Christian, Jew, or Muslim) as regarded by those who do."
 } 
console.log(dict.beautiful)