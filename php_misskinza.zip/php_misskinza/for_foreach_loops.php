<!-- for loop -->
 <!-- for listed (single deminsional array) -->
 <h1>BY FOR LOOP</h1>
<h2>*single dimentional array*</h2>
  <?php
  $name = ["sani","ali","abiha","sana","abrar"];
  $city =["karachi","multan","lahore","islamabad","peshawar"]
  ?>
  <ul>
    <?php
    for ($i=0 ; $i<count($name) ; $i++){
        ?>
        <li>
            <?php 
        echo$name[$i]
        ?>
        </li>
        <?php
    }
    ?>
  </ul>

<!-- for loop  -->
 <!-- table (multiple dimentional array) -->
 <h2>*table multi dimentional array*</h2>
 <?php
  $data=[
    ["isha","isha@gmail.com",16,"karachi","pakistan"],
    ["eshal","eshal@gmail.com",25,"quetta","pakistan"],
    ["samar","sana@gmail.com",14,"peshawar","pakistan"],
    ["tatheer","tatheer@gmail.com",23,"islamabad","pakistan"],
    ["Aliza","aliza@gmail.com",12,"multan","pakistan"],
    ["Daniyal","daniyal@gmail.com",17,"karachi","pakistan"],
    ["Raza","raza@gmail.com",29,"islamabad","pakistan"],
    ["Sani","sani@gmail.com",20,"peshawar","pakistan"],
    ["Nosheen","nosheen@gmail.com",18,"multan","pakistan"],
    ["Waliya","waliya@gmail.com",15,"lahore","pakistan"]

  ]
  ?>
  <table border="1">
    <thead>
   <tr>
    <th>NAME:-</th>
    <th>EMAIL:-</th>
    <th>AGE:-</th>
    <th>CITY:-</th>
    <th>COUNTRY:-</th>

   </tr>
    </thead>
    <tbody>
        <?php
        for($j=0;$j<count($data);$j++){
            ?>
            <tr>
                <?php
                for($k=0;$k<count($data[$j]);$k++){
                    ?>
                    <td><?php echo $data[$j][$k]?></td>
                    <?php
                }
                ?>
            </tr>
            <?php
        }
        ?>
    </tbody>
  </table>
  <br><br>
  <!-- foreach loop  -->
   <!-- listed single dimentional array -->
   <h1>BY FOR EACH LOOP</h1>
   <h2>*single dimentional array*</h2>

    <?php
    $data2 =["fatima",23,"karachi"]

    ?>
    <ul>
      <?php
      foreach($data2 as $i){
        ?>
        <li><?php echo$i?></li>
        <?php
      }
      ?>
    </ul>

    <!-- table foreach loop -->
     <!-- multidimentional array -->
      <h2>*table multi dimentional array*</h2>
      <?php
      $table_data=[
        ["Raza","karachi",23,"pakistan"],
        ["Yasir","lahore",28,"pakistan"],
        ["Aliya","multan",14,"pakistan"],
        ["Sara","islamabad",26,"pakistan"],
        ["Fakhir","peshawar",18,"pakistan"],
        ["Sumbul","karachi",25,"pakistan"],
        ["Miraal","islamabad",15,"pakistan"],
        ["Jannat","multan",24,"pakistan"],
        ["Haider","lahore",26,"pakistan"],
        ["ghazi","karachi",18,"pakistan"]
      ]
      ?>
      <table border = "1">
        <thead>
          <tr>
            <th>NAME:-</th>
            <th>CITY:-</th>
            <th>AGE:-</th>
            <th>COUNTRY:-</th>
          </tr>
        </thead>
        <tbody>
          <?php
        foreach($table_data as $u){
          ?>
          <tr>
            <?php
            foreach($u as $final_data){
              ?>
              <td><?php 
              echo$final_data
              ?></td>
              <?php
            }
            ?>
          </tr>
          <?php
        }
          ?>
        </tbody>
      </table>