<?php
//variables $ is the symbol of variables
//html
$name ="sani";
$email = "sz1769193@gmail.com";
echo "<h1>$name</h1>";
print "<h1>$email</h1>";
echo "hello world <br>";
print "hello world";
//css
echo "<h1 style = 'color:red'>hello world</h1>";
//java
//echo "<script>alert('working')</script>";

//concidinate
echo $name.$email;
?>