<?php
$associative =[
    ["name"=>"fatima","age"=>23],
    ["name"=>"azhar","age"=>15],
    ["name"=>"tahir","age"=>19],
    ["name"=>"mehak","age"=>28],
    ["name"=>"ali","age"=>25],
    ["name"=>"hussain","age"=>18],
    ["name"=>"ghazi","age"=>20],
    ["name"=>"rida","age"=>24],
    ["name"=>"sana","age"=>12],
    ["name"=>"daniyal","age"=>17],
    ["name"=>"yasir","age"=>21],

]
?>
<table border ="2">
    <thead>
        <tr>
            <th>NAME:-</th>
            <th>AGE:-</th>
        </tr>
    </thead>
    <tbody>
        <?php
        foreach($associative as $i){
            ?>
            <tr>
                <?php
                foreach($i as $j){
                    ?>
                    <td><?php echo$j?>
                    </td>
                    <?php
                }
                ?>
            </tr>
            <?php
        }
        ?>
    </tbody>
</table>
