<?php
$name="sani";
$email="sanizehra@gmail.com";
$city="karachi";
$age=16;
$address="sharah e faisal";

//question 1  (html & css)

echo"<p>$name</p>";
echo"<p style= 'color:blue'>$email</p>";

//question 2  (java + hmtl + css)

print "<script>

console.log('$city')

</script>";

//print "<script></script>"
print "<script>
document.write('<h1>$address</h1>');  
document.write('<p>$age</p>')
</script>";

//question 3  (concidinates)
echo"<p style= 'color:red'>$name.$email.$city.$age.$address</p>";
?>
