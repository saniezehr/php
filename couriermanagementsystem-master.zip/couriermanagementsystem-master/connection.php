<?php
// Connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "couriersystem";

// Create connection
$conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);


?>


